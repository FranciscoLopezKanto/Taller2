
public class ListaProfesor {

	private int cantProfesor,max;
	private Profesor[]lista;
	
	
	public ListaProfesor(int max) {
		// TODO Auto-generated constructor stub
		lista= new Profesor[max];
		cantProfesor = 0;
		this.max = max;
	}
	public boolean ingresarProfesor(Profesor profesor){
		if (cantProfesor < max){
			lista[cantProfesor]= profesor;
			cantProfesor ++;
			return true;
		}
		else{
			return false;
		}
	}
	public Profesor getProfesorI(int i){
		if (i >=0 && i < cantProfesor){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public Profesor buscarProfesor(String correo){
		int i;
		for(i = 0; i < cantProfesor; i++){
			if (lista[i].getCorreo().equals(correo)){
				break;
			}
		}
		if (i == cantProfesor){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getCantProfesor() {
		return cantProfesor;
	}
	public void setCantProfesor(int cantProfesor) {
		this.cantProfesor = cantProfesor;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
	public Profesor[] getLista() {
		return lista;
	}
	public void setLista(Profesor[] lista) {
		this.lista = lista;
	}
	
}
