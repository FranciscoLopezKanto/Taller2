
public class ListaAlumno {
	private int cantAlumno,max;
	private Alumno []lista;

	
	
	
	public ListaAlumno(int max) {
		// TODO Auto-generated constructor stub
		lista= new Alumno[max];
		cantAlumno = 0;
		this.max = max;
	}
	public boolean ingresarAlumno(Alumno alumno){
		if (cantAlumno < max){
			lista[cantAlumno]= alumno;
			cantAlumno ++;
			return true;
		}
		else{
			return false;
		}
	}
	public Alumno getAlumnoI(int i){
		if (i >=0 && i < cantAlumno){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public Alumno buscarAlumno(String correo){
		int i;
		for(i = 0; i < cantAlumno; i++){
			if (lista[i].getCorreo().equals(correo)){
				break;
			}
		}
		if (i == cantAlumno){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
	
	public int getCantAlumno() {
		return cantAlumno;
	}
	public void setCantAlumno(int cantAlumno) {
		this.cantAlumno = cantAlumno;
	}
	public boolean eliminarAsignatura(Alumno alumno) {
		int i = 0;
		while(i < cantAlumno && lista[i].getCodigo()!=alumno.getCodigo()) {
			i++;
		}
		if(i == cantAlumno) {
		
			return false;
		}
		else {
			for(int k = i; k < cantAlumno-1; k++) {
				lista[k]=lista[k+1];
			}
			cantAlumno--;
			return true;
		}
	}
}
