
public interface SistemaUCR {
	public boolean IngresarEstudiante(String Rut,String Correo,int Nivel,String contrase�a);
	public boolean IngresarAsignaturaObligatoria(String Codigo,String NombreA,int Creditos,String tipo,int NivelMalla,int CantPrerequisito,int CantCodigos);
	public boolean IngresarAsignaturaOpcional(String Codigo,String NombreA,int Creditos,String tipo,int MinimoCreditos);
	public boolean IngresarProfesor(String Rut,String Correo,String Contrase�a,int Salario);
	public boolean IngresarParalelo(int Nparalelo,String Codigo,String rutProfesor);
	public void InicioSesion(String Correo,String Contra);
	public void InscripcionAsignaturas(String dato);
	public void EliminacionAsignaturas(String dato);
	public void ChequeoAlumnos(String profe);
	public void IngresoNotaFinal(String dato);
	public String ObtenerInformacionSemestre();
}
