public class Alumno {
	private String Rut;
	private String Correo;
	private int Nivel;
	private String Contra;
	private int cantcreditos;
	private String Codigo;
	private ListaAsignatura lista;
	
	public Alumno(String Rut,String Correo,int Nivel,String Contra) {
		this.Rut=Rut;
		this.Correo=Correo;
		this.Nivel=Nivel;
		this.Contra=Contra;
		cantcreditos=0;
		ListaAsignatura lista = new ListaAsignatura(100);
	
		
	}
	public ListaAsignatura getLista() {
		return lista;
	}
	public void setLista(ListaAsignatura lista) {
		this.lista = lista;
	}
	public String getCodigo() {
		return Codigo;
	}
	public void setCodigo(String codigo) {
		Codigo = codigo;
	}
	public int getCantcreditos() {
		return cantcreditos;
	}
	public void setCantcreditos(int cantcreditos) {
		this.cantcreditos = cantcreditos;
	}
	public String getRut() {
		return Rut;
	}
	public void setRut(String rut) {
		Rut = rut;
	}
	public String getCorreo() {
		return Correo;
	}
	public void setCorreo(String correo) {
		Correo = correo;
	}
	public int getNivel() {
		return Nivel;
	}
	public void setNivel(int nivel) {
		Nivel = nivel;
	}
	public String getContra() {
		return Contra;
	}
	public void setContra(String contra) {
		Contra = contra;
	}
	
	
	
}
