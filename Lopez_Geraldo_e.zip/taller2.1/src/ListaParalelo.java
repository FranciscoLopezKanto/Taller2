
public class ListaParalelo {
	private int cantParalelo,max;
	private Paralelo[]lista;
	public ListaParalelo(int max) {
		// TODO Auto-generated constructor stub
		lista= new Paralelo[max];
		cantParalelo = 0;
		this.max = max;
	}
	public boolean ingresarParalelo(Paralelo paralelo){
		if (cantParalelo < max){
			lista[cantParalelo]= paralelo;
			cantParalelo ++;
			return true;
		}
		else{
			return false;
		}
	}
	public Paralelo getParaleloI(int i){
		if (i >=0 && i < cantParalelo){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public Paralelo buscarParalelo(int paralelo){
		int i;
		for(i = 0; i < cantParalelo; i++){
			if (lista[i].getNumeroParalelo()==(paralelo)){
				break;
			}
		}
		if (i == cantParalelo){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public Paralelo buscarParaleloprofe(String dato){
		int i;
		for(i = 0; i < cantParalelo; i++){
			if (lista[i].getProfesor().getCorreo()==(dato)){
				break;
			}
		}
		if (i == cantParalelo){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
	public int getCantParalelo() {
		return cantParalelo;
	}
	public void setCantParalelo(int cantParalelo) {
		this.cantParalelo = cantParalelo;
	}
	public Paralelo[] getLista() {
		return lista;
	}
	public void setLista(Paralelo[] lista) {
		this.lista = lista;
	}
	
}
