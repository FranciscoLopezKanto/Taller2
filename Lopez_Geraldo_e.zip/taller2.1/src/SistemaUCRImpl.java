

import ucn.StdIn;

public class SistemaUCRImpl implements SistemaUCR {
	private ListaAlumno ListaAlumno;
	private ListaAsignatura  ListaAsignatura;
	private ListaParalelo  ListaParalelo;
	private ListaProfesor ListaProfesor ;

	public SistemaUCRImpl() {
		this.ListaAlumno=new ListaAlumno(1000);
		this.ListaAsignatura=new ListaAsignatura(1000);
		this.ListaParalelo=new ListaParalelo(1000);
		this.ListaProfesor=new ListaProfesor(1000);
	}
	@Override
	/**
	  * Student is entered into the Student list
	  *  @param rut,Correo,Nivel,contrase�a
	  *  @return ingreso
	  *  */
	public boolean IngresarEstudiante(String Rut, String Correo, int Nivel, String contrase�a) {
		// TODO Auto-generated method stub
		Alumno alumno = new Alumno(Rut, Correo, Nivel, contrase�a);
		boolean ingreso = ListaAlumno.ingresarAlumno(alumno);
		return ingreso;
	}
	/**
	  * Compulsory subject is entered in the list of subjects
	  *  
	  *  */
	public boolean IngresarAsignaturaObligatoria(String Codigo, String NombreA, int Creditos, String tipo,
			int NivelMalla, int CantPrerequisito,int CantCodigos) {
		// TODO Auto-generated method stub
		Asignatura asignatura = new Obligatoria (Codigo, NombreA,Creditos,tipo,NivelMalla,CantPrerequisito, CantCodigos);
		boolean ingreso = ListaAsignatura.ingresarAsignatura(asignatura);
		return ingreso;
		
	}
	 /**
	  * Optional Subject is entered into the list of subjects
	  *  
	  *  */
	@Override
	public boolean IngresarAsignaturaOpcional(String Codigo, String NombreA, int Creditos, String tipo,
			int MinimoCreditos) {
		// TODO Auto-generated method stub
		Asignatura asignatura = new Opcional (Codigo, NombreA,Creditos,tipo,MinimoCreditos);
		boolean ingreso = ListaAsignatura.ingresarAsignatura(asignatura);
		return ingreso;
		
	}
	/**
	  * Teacher is entered into the list of teachers
	  *  
	  *  */
	@Override
	public boolean IngresarProfesor(String Rut, String Correo, String Contrase�a, int Salario) {
		// TODO Auto-generated method stub
		Profesor profesor = new Profesor(Rut, Correo, Contrase�a, Salario);
		boolean ingreso = ListaProfesor.ingresarProfesor(profesor);
		return ingreso;
		
	}
	/**
	  * Parallel is entered into the Parallel list
	  *  
	  *  */
	public boolean IngresarParalelo(int Nparalelo, String Codigo,String rutProfesor) {
		// TODO Auto-generated method stub
		Profesor profesor = ListaProfesor.buscarProfesor(rutProfesor);
		Paralelo paralelo = new Paralelo(Nparalelo,Codigo);
		paralelo.setProfesor(profesor);
		boolean ingreso = ListaParalelo.ingresarParalelo(paralelo);
		return ingreso;
	}
	/**
	  * The session is started and the date is asked, once entered the options  
	  * will be displayed according to the period and the user who entered
	  *  */
	public void InicioSesion(String Correo, String Contra) {
        String admin="Admin";
        String admincontra ="GHI_789";
        
        Alumno a = ListaAlumno.buscarAlumno(Correo);
        if(a==null) {
            Profesor p = ListaProfesor.buscarProfesor(Correo);
            if(p==null) {
                if(admin.equals(Correo)) {
                    if(admincontra.equals(Contra)){
                        ObtenerInformacionSemestre();
                    }
                }
            }
            else {
                if(p.getContra().equals(Contra)) {
                    System.out.print("Ingrese Dia de la fecha: ");
                    int dia = StdIn.readInt();
                    System.out.print("Ingrese Mes de la fecha: ");
                    int mes = StdIn.readInt();
                    if((dia>=8 && mes>=3)&& (dia<=2 && mes<=5)) {
                        ChequeoAlumnos(Correo);
                    }
                    else if((dia>=12 && mes >= 7)&&(dia<=25 && mes<=7)) {
                        IngresoNotaFinal(Correo);
                    }
                    else {
                        System.out.print("No hay opciones disponibles en este periodo");
                    }
                }
                else {
                    System.out.print("Contrase�a incorrecta");
                }
            }
        }
        else {
            if(a.getContra().equals(Contra)) {
                System.out.print("Ingrese Dia de la fecha: ");
                int dia = StdIn.readInt();
                System.out.print("Ingrese Mes de la fecha: ");
                int mes = StdIn.readInt();
                if((dia>=8 && mes>=3)&& (dia<=2 && mes<=5)) {
                    System.out.print("1)Inscripcion de asignatunas\n"+
                "2)Eliminacion de asignaturas\n"+
                "Ingrese una opcion: ");
                    int opcion = StdIn.readInt();
                    if(opcion==1) {
                        InscripcionAsignaturas(Correo);
                    }
                    else if(opcion==2){
                        EliminacionAsignaturas(Correo);
                    }
                    else {
                        System.out.print("Contrase�a incorrecta");
                        System.out.print("Volver a iniciar sesion");
                    }
                    
                }
                else if((dia>=3 && mes >= 5)&&(dia<=11 && mes<=7)) {
                    EliminacionAsignaturas(Correo);
                }
                else {
                    System.out.print("Disfrute sus vacaciones");
                }
            }
            else {
                System.out.print("Contrase�a incorrecta");
            }
            
            
        }
        
    }
	/**
	  * The subjects that the student can enroll must be 
	  *  
	  *  */
	public void InscripcionAsignaturas(String dato) {
		String datos = "";
		String datosparalelo = "";
		for(int i =0; i< ListaAlumno.getCantAlumno();i++) {
			Alumno a = ListaAlumno.getAlumnoI(i);
			if(a.getCorreo().equals(dato)) {
				int nivel = a.getNivel();
				for(int j = 0; j< ListaAsignatura.getCantAsignatura();j++) {
					Asignatura asign = ListaAsignatura.getAsignaturaI(j);
					if(asign instanceof Obligatoria) {
						Asignatura asign1 = (Obligatoria) asign;
						int nivelA = ((Obligatoria) asign).getNivelMalla();
						if(nivel<nivelA) {
							datos+=asign.getNombreAsignatura();
						}
					}
					datos+=asign.getNombreAsignatura()+"/Codigo: " +asign.getCodigo();
					
					
				}
				System.out.print(datos);
				
				
				
			}
		}
		System.out.print("Ingrese codigo de Asignatura a dar: ");
		String resp = StdIn.readString();
		Asignatura as = ListaAsignatura.buscarAsignatura(resp);
		for(int k = 0; k<ListaParalelo.getCantParalelo();k++) {
			Paralelo pa = ListaParalelo.getParaleloI(k);
			if(pa.getCodigo().equals(resp)) {
				datosparalelo+= "Paralelo: "+pa.getNumeroParalelo()+"Profesor: "+pa.getProfesor();
				
			}
			System.out.print("Ingrese Paralelo a dar: ");
			int numero = StdIn.readInt();
			if(pa.getNumeroParalelo()==numero) {
				Alumno al = ListaAlumno.buscarAlumno(dato);
				al.setCodigo(resp);
			}
		}
		
		
	}
	/**
	  *  All the subjects that the student has registered so far must be shown 
	  *  then the student is given the option to choose any of these to eliminate it.
	  *  
	  *  */
	public void EliminacionAsignaturas(String dato) {
		// TODO Auto-generated method stub
		String Dato = "Asignaturas: ";
		for(int i =0; i < ListaAlumno.getCantAlumno();i++){
			Alumno a = ListaAlumno.getAlumnoI(i);
			if(a.getCorreo().equals(dato)) {
				dato+=a.getCodigo();
			}
			System.out.print(dato);
			System.out.print("Ingrese Codigo Asignatura a eliminar: ");
			String resp = StdIn.readString();
			
		}
		
		
		
	}
	/**
	  * All the parallels that the teacher must dictate this 
	  *  
	  *  */
	public void ChequeoAlumnos(String profe) {
		// TODO Auto-generated method stub
		String datos="Paralelos\n";
		int paralelo;
		Paralelo profe1 = ListaParalelo.buscarParaleloprofe(profe);
		for (int i = 0 ; i< ListaParalelo.getCantParalelo();i++) {
			if(profe1.getProfesor().getCorreo().equals(profe)) {
				paralelo = profe1.getNumeroParalelo();
				datos+=profe1.getNumeroParalelo();
			}
		}
		System.out.print(datos);
		
	}
	/**
	  * Ohe teacher is shown all the subjects that he dictates, once one has been selected, 
	  *  a student is selected and the corresponding final grade is entered.
	  *  */
	public void IngresoNotaFinal(String dato) {
		String datos="";
		Paralelo profe1 = ListaParalelo.buscarParaleloprofe(dato);
		for (int i = 0 ; i< ListaParalelo.getCantParalelo();i++) {
			if(profe1.getProfesor().getCorreo().equals(dato)) {
				datos+=profe1.getCodigo();
				
						
				
			}
		}
	}
	/**
	  * The semester information is displayed
	  *  
	  *  */
	public String ObtenerInformacionSemestre() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}