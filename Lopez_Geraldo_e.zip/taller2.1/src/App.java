import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import ucn.ArchivoEntrada;
import ucn.Registro;
import ucn.StdIn;

public class App {
	public static void read(SistemaUCR sistema) throws IOException {
        //11.111.111-1, Jorge.perez@alumnos.ucn.cl,3, Abc_123
        //5
        //1458,3.2}
        //1523,4.8}
        //1211,2.1}  5 cursadas 
        //1428,6.1}
        //1458,4.0}
        //0
        BufferedReader s = new BufferedReader(new FileReader("Estudiantes.txt"));
        String linea;
        
        while((linea = s.readLine()) != null) {
            String[] partes = linea.split(",");
            
            String rut= partes[0];
            String correo=partes[1];
            int nivel= Integer.parseInt(partes[2]);
            String contra=partes[3];;
            linea=s.readLine();
            String[] partes2=linea.split(",");
            int cantAsignaturas=Integer.parseInt(partes2[0]);
            sistema.IngresarEstudiante(rut,correo,nivel,contra);
        
            for(int i=0;cantAsignaturas>=i;i++) {
                linea=s.readLine();
                String[] partes3 = linea.split(",");
                String Asignatura = partes3[0] ;
                double Nota= Double.parseDouble(partes3[1]);
                //Tu asociar que no se que wea hace
                
                
                
                
            }
            
            
        }
        s.close();
        
        ArchivoEntrada arch2=new ArchivoEntrada("Profesores.txt");
        while(!arch2.isEndFile()) {
            //22.222.222-2, Renka.rodriguez@ucn.cl, Def_456, 1350000
            Registro r=arch2.getRegistro();
            String rut= r.getString();
            String correo=r.getString();
            String contra=r.getString();
            int salario=r.getInt();
            sistema.IngresarProfesor(rut, correo, contra, salario);
            
        }
        ArchivoEntrada arch3=new ArchivoEntrada("Paralos.txt");
        while(!arch3.isEndFile()) {
            // 1, 1285 , 22.222.222-2
            Registro r=arch3.getRegistro();
            int Nparalelo= r.getInt();
            String codigo=r.getString();
            String nombreP=r.getString();
            
            sistema.IngresarParalelo(Nparalelo, codigo, nombreP);
        }
        
            
        ArchivoEntrada arch4=new ArchivoEntrada("Asignaturas.txt");
        while(!arch4.isEndFile()) {
            //Ejemplo: 1285, termodinámica, 8, obligatoria, 2, 3, 1284, 1085, 9450
            //Ejemplo: 1286, belga, 4, opcional, 14
            
            Registro r=arch4.getRegistro();
            String codigo= r.getString();
            String nombreAsignatura=r.getString();
            int creditos=r.getInt();
            String tipo =r.getString();
            
            if(tipo.equals("opcional")) {
                int MinimoCreditos= r.getInt();
                sistema.IngresarAsignaturaOpcional( codigo,nombreAsignatura, creditos, tipo, MinimoCreditos);
                
            }else {
                if(tipo.equals("obligario")) {
                    int NivelMalla=r.getInt();
                    int CantPrerequisito=r.getInt();
                    int CantCodigos=r.getInt();
                    for (int i=0;CantCodigos>=i;i++) {
                        String codigoAsignatura=r.getString();
                        Obligatoria.AgregarCodigos(codigoAsignatura);
                    }
                    
                    sistema.IngresarAsignaturaObligatoria(codigo, nombreAsignatura, creditos, tipo, NivelMalla, CantPrerequisito, CantCodigos);
                }
            
    }
}
    
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SistemaUCR sistema = new SistemaUCRImpl();
		System.out.print("Ingrese Correo: ");
		String correo = StdIn.readString();
		System.out.print("Ingrese Contra: ");
		String contra = StdIn.readString();
		sistema.InicioSesion(correo, contra);
		
	}

}
