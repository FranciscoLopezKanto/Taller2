
public class Profesor {
	private String RutP;
	private String Correo;
	private String Contra;
	private int Salario;
	private ListaParalelo lista;

	public ListaParalelo getLista() {
		return lista;
	}

	public Profesor(String rutP, String correo, String contra, int salario) {

		this.RutP = rutP;
		this.Correo = correo;
		this.Contra = contra;
		this.Salario = salario;
		ListaParalelo lista = new ListaParalelo(4);
	}
	public String getRutP() {
		return RutP;
	}
	public void setRutP(String rutP) {
		RutP = rutP;
	}
	public String getCorreo() {
		return Correo;
	}
	public void setCorreo(String correo) {
		Correo = correo;
	}
	public String getContra() {
		return Contra;
	}
	public void setContra(String contra) {
		Contra = contra;
	}
	public int getSalario() {
		return Salario;
	}
	public void setSalario(int salario) {
		Salario = salario;
	}
	
}
