
public class Paralelo {
	private int NumeroParalelo ;
	private String Codigo;
	private Profesor profesor;
	private ListaAsignatura lista;
	private Asignatura Nombre;
	public Profesor getProfesor() {
		return profesor;
	}
	public void setProfesor(Profesor profesor) {
		this.profesor = profesor;
	}
	public Paralelo(int NumeroParalelo,String Codigo) {
		this.Codigo=Codigo;
		this.NumeroParalelo=NumeroParalelo;
		profesor = null;
		Nombre=null;
		ListaAsignatura lista = new ListaAsignatura(100);
	}
	public ListaAsignatura getLista() {
		return lista;
	}
	public void setLista(ListaAsignatura lista) {
		this.lista = lista;
	}
	public Asignatura getNombre() {
		return Nombre;
	}
	public void setNombre(Asignatura nombre) {
		Nombre = nombre;
	}
	public int getNumeroParalelo() {
		return NumeroParalelo;
	}
	public void setNumeroParalelo(int numeroParalelo) {
		NumeroParalelo = numeroParalelo;
	}
	public String getCodigo() {
		return Codigo;
	}
	public void setCodigo(String codigo) {
		Codigo = codigo;
	}

}
