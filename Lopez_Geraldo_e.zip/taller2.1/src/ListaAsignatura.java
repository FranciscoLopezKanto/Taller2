
public class ListaAsignatura {
	private int cantAsignatura,max;
	private Asignatura[]lista;
	
	public ListaAsignatura(int max) {
		// TODO Auto-generated constructor stub
		lista= new Asignatura[max];
		cantAsignatura = 0;
		this.max = max;
	}
	public boolean ingresarAsignatura(Asignatura alumno){
		if (cantAsignatura < max){
			lista[cantAsignatura]= alumno;
			cantAsignatura ++;
			return true;
		}
		else{
			return false;
		}
	}
	public Asignatura getAsignaturaI(int i){
		if (i >=0 && i < cantAsignatura){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public Asignatura buscarAsignatura(String resp){
		int i;
		for(i = 0; i < cantAsignatura; i++){
			if (lista[i].getCodigo().equals(resp)){
				break;
			}
		}
		if (i == cantAsignatura){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getCantAsignatura() {
		return cantAsignatura;
	}
	public void setCantAsignatura(int cantAsignatura) {
		this.cantAsignatura = cantAsignatura;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
	public Asignatura[] getLista() {
		return lista;
	}
	public void setLista(Asignatura[] lista) {
		this.lista = lista;
	}
	
	
}
