
public class Obligatoria extends Asignatura {

	private int NivelMalla;
	private int CantPrerequisito;
	private static String [] codigos;
	private int CantCodigos;;
	private static int contador = 0;
	public Obligatoria(String codigo, String nombreAsignatura, int creditos, String tipo,int NivelMalla,int CantPrerequisito,int CantCodigos) {
		super(codigo, nombreAsignatura, creditos, tipo);
		this.NivelMalla= NivelMalla;
		this.CantPrerequisito=CantPrerequisito;
		this.CantCodigos = CantCodigos;
	}
	public int getNivelMalla() {
		return NivelMalla;
	}
	public void setNivelMalla(int nivelMalla) {
		NivelMalla = nivelMalla;
	}
	public int getCantPrerequisito() {
		return CantPrerequisito;
	}
	public void setCantPrerequisito(int cantPrerequisito) {
		CantPrerequisito = cantPrerequisito;
	}
	public String[] getCodigos() {
		return codigos;
	}
	public void setCodigos(String[] codigos) {
		Obligatoria.codigos = codigos;
	}
	public int getCantCodigos() {
		return CantCodigos;
	}
	public void setCantCodigos(int cantCodigos) {
		CantCodigos = cantCodigos;
	}
	public static void AgregarCodigos(String codigoAsignatura) {
        
		codigos[contador]=codigoAsignatura;
        contador++;

    }
}
